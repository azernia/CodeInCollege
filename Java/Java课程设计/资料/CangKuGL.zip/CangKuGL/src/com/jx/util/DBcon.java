package com.jx.util;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBcon {
	public static Connection getConnection(){
		Connection conn = null;
		// �������ݿ��������
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url = "jdbc:sqlserver://localhost:1433;DatabaseName=jixudata";
			String username = "sa";
			String password = "111111";
			conn = DriverManager.getConnection(url,username,password); 
			System.out.println("���ӳɹ���");
		} catch (ClassNotFoundException e) {
			System.out.println("����ʧ�ܣ�");
			e.printStackTrace();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void closeConn(Object o){
		if(o!=null){
			if(o instanceof Connection){
				try {
					((Connection)o).close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if(o instanceof Statement){
				try {
					((Statement)o).close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if(o instanceof PreparedStatement){
				try {
					((PreparedStatement)o).close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if(o instanceof ResultSet){
				try {
					((ResultSet)o).close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
