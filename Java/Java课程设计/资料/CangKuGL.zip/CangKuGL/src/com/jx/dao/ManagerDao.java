package com.jx.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jx.dto.Manager;
import com.jx.util.DBcon;

public class ManagerDao {
	//У���û�
	public Manager validate(Manager manager) {
		Manager m = null;
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			String sql = "select managername,password,level from manager where managername=? and password=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, manager.getManagername());
			pst.setString(2, manager.getPassword());
			rs = pst.executeQuery();
			if (rs.next()) {
				m = new Manager();
				m.setManagername(rs.getString("managername"));
				m.setPassword(rs.getString("password"));
				m.setLevel(rs.getInt("level"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(rs);
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return m;
	}
	//�����û�
	public boolean addManager(Manager manager) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = DBcon.getConnection();
			String sql = "insert into manager(managername,password,level) values(?,?,?);";
			pst = conn.prepareStatement(sql);
			pst.setString(1, manager.getManagername());
			pst.setString(2, manager.getPassword());
			pst.setInt(3, manager.getLevel());
			if (pst.executeUpdate() > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return flag;
	}
	//ɾ���û�
	public boolean DelManager(String managername) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;

		try {
			conn = DBcon.getConnection();
			String sql = "DELETE FROM manager WHERE managername = "+managername;
			pst = conn.prepareStatement(sql);
			if (pst.executeUpdate() > 0) {
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return flag;
	}

	//����manaername���û�
	public Manager queryOne(String managername) {
		Manager m = null;
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			String sql = "select managername,level from manager where managername="+managername;
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			if (rs.next()) {
				m = new Manager();
				m.setManagername(rs.getString("managername"));
				m.setLevel(rs.getInt("level"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(rs);
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return m;
	}
}
