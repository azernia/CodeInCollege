package com.jx.dto;

import java.sql.Date;

public class CKInfo {
	private String fno;
	private String dept;
	private Date outtime;
	private String outstate;
	private String jsr;
	private int outmount;
	private String lqr;
	private String usefor;
	public String getFno() {
		return fno;
	}
	public void setFno(String fno) {
		this.fno = fno;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Date getOuttime() {
		return outtime;
	}
	public void setOuttime(Date outtime) {
		this.outtime = outtime;
	}
	public String getOutstate() {
		return outstate;
	}
	public void setOutstate(String outstate) {
		this.outstate = outstate;
	}
	public String getJsr() {
		return jsr;
	}
	public void setJsr(String jsr) {
		this.jsr = jsr;
	}
	public int getOutmount() {
		return outmount;
	}
	public void setOutmount(int outmount) {
		this.outmount = outmount;
	}
	public String getLqr() {
		return lqr;
	}
	public void setLqr(String lqr) {
		this.lqr = lqr;
	}
	public String getUsefor() {
		return usefor;
	}
	public void setUsefor(String usefor) {
		this.usefor = usefor;
	}
	
	
	
	
	

}
