package com.jx.frame;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class FileLY extends JFrame implements ActionListener,ListSelectionListener {
	private JLabel jLabel1,jLabel2,jLabel3,jLabel4,jLabel5;
	private JTextField textField1,textField2,textField3,textField4;
	private JButton button_open,button_delete,button_save,button_copy,button_rename,button_new;
	private JTextArea textArea;
	private JPanel jPanel1,jPanel11,jPanel12,jPanel13,jPanel14,jPanel15,jPanel16,panel_b;
	private Dimension dimension;
	private JList jList,list_b;
	private File files[],dir;
	public FileLY() {
		// TODO Auto-generated constructor stub
		super("�ļ�ϵͳ");
		dimension = getToolkit().getScreenSize();  //�����Ļ��С
		this.setBounds(dimension.width/5, dimension.height/5, dimension.width/2, dimension.height*2/3);
		this.setLayout(new GridLayout(2, 1));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		textArea=new JTextArea();
		textArea.setLineWrap(true);
		this.add(textArea);
		jPanel1 = new JPanel(new GridLayout(6, 1));
		this.add(jPanel1);
		//******jpanel11
		jPanel11 =new JPanel(new GridLayout(1,2));
		jPanel1.add(jPanel11);
		jLabel1 = new JLabel("��ǰĿ¼��");
		textField1 = new JTextField();
		jPanel11.add(jLabel1);
		jPanel11.add(textField1);
		//*******jpanel12
		jPanel12 = new JPanel(new GridLayout(1,2));
		jPanel1.add(jPanel12);
		jLabel2 = new JLabel("�ļ���");
		textField2 = new JTextField();
		jPanel12.add(jLabel2);
		jPanel12.add(textField2);
		//**********jpanel16
		jPanel16 = new JPanel(new GridLayout(1,2));
		jPanel1.add(jPanel16);
		jLabel5 = new JLabel("�ļ�����:");
		Object p[]={"ֻ��","�ɶ���д"};
		jList = new JList(p);
		jList.addListSelectionListener(this);
		jPanel16.add(jLabel5);
		jPanel16.add(jList);
		//*******jpanel13
		jPanel13 = new JPanel(new GridLayout(1,3));
		jPanel1.add(jPanel13);
		button_new = new JButton("�½�");
		button_open = new JButton("��");
		button_delete = new JButton("ɾ��");
		button_save = new JButton("����");
		button_new.addActionListener(this);
		button_open.addActionListener(this);
		button_delete.addActionListener(this);
		button_save.addActionListener(this);
		jPanel13.add(button_new);
		jPanel13.add(button_open);
		jPanel13.add(button_delete);
		jPanel13.add(button_save);
		//*******jpanel14
		jPanel14 = new JPanel(new GridLayout(1,3));
		jPanel1.add(jPanel14);
		jLabel3 = new JLabel("���Ƶ���");
		textField3 = new JTextField();
		button_copy = new JButton("����");
		button_copy.addActionListener(this);
		jPanel14.add(jLabel3);
		jPanel14.add(textField3);
		jPanel14.add(button_copy);
		//***********jpanel15
		jPanel15 = new JPanel(new GridLayout(1,2));
		jPanel1.add(jPanel15);
		jLabel4 = new JLabel("����Ϊ��");
		textField4 = new JTextField();
		button_rename = new JButton("������");
		button_rename.addActionListener(this);
		jPanel15.add(jLabel4);
		jPanel15.add(textField4);
		jPanel15.add(button_rename);
//		list_b=new JList();
//		panel_b=new JPanel();
//		panel_b.add(list_b);
		
		
		
		
		this.setVisible(true);
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button_new)
		{
			try {
				File_New(textField1.getText()+textField2.getText());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==button_open)   //��
		{
//			dir=new File(textField1.getText());
//			String[] filenames=dir.list();
//			System.out.println(filenames);
			try {
				File_Open(textField1.getText()+textField2.getText());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==button_save)    //���棨ʵ���޸ģ�
		{
			try {
				File_Save(textField1.getText()+textField2.getText());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==button_copy)    //����
		{
			try {
				File_Copy(textField1.getText()+textField2.getText(),textField3.getText()+textField2.getText());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==button_delete)  //ɾ��
		{
			try {
				File_Delete(textField1.getText()+textField2.getText());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==button_rename)
		{
			try {
				File_Rename(textField1.getText()+textField2.getText(),textField1.getText()+textField4.getText());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	//******�½�
	public void File_New(String fileName) throws IOException
	{
		File f= new File(fileName);
		f.createNewFile();
	}
	//********��
	public void File_Open(String fileName_o) throws IOException
	{
		FileInputStream fin = new FileInputStream(fileName_o);
		DataInputStream cin = new DataInputStream(fin);

		String str;

		while(true)
		{
			try
			{
				str = String.format("%c",cin.readChar());
				textArea.setText(str);

			}
			catch(EOFException e)
			{
				break;
			}
		}
		cin.close();
		fin.close();
	}
	//**********����
	public void File_Save(String fileName_s) throws IOException
	{
		FileOutputStream fout = new FileOutputStream(fileName_s);
		DataOutputStream cout = new DataOutputStream(fout);
		String str = textArea.getText();
		cout.writeChars(str);
		
		cout.close();
		fout.close();
	}
	//************����
	public void File_Copy(String fileName,String fileName1) throws IOException
	{
		FileInputStream fin = new FileInputStream(fileName);
		DataInputStream cin = new DataInputStream(fin);
		FileOutputStream fout = new FileOutputStream(fileName1);
		DataOutputStream cout = new DataOutputStream(fout);

		String str;

		while(true)
		{
			try
			{
				str = String.format("%c",cin.readChar());
				cout.writeChars(str);

			}
			catch(EOFException e)
			{
				break;
			}
		}
		cin.close();
		fin.close();
		cout.close();
		fout.close();
	}
	//**************ɾ��
	public void File_Delete(String fileName_d) throws IOException
	{
		File f= new File(fileName_d);
		f.delete();
	}
	//****************������
	public void File_Rename(String fileName,String fileName1) throws IOException
	{
		File f= new File(fileName);
		File f1= new File(fileName1);
		f.renameTo(f1);
	}
	
	public static void main(String[] args) {
		new FileLY();
	}
	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		String str= (String) jList.getSelectedValue();
		if(str.equals("ֻ��"))
		{
			this.textArea.setEditable(false);
		}
		if(str.equals("�ɶ���д"))
		{
			this.textArea.setEditable(true);
		}
	}

}
