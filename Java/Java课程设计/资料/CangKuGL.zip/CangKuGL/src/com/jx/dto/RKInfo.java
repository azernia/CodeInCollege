package com.jx.dto;

import java.sql.Date;

public class RKInfo {
	private String fno;
	private Date intime;
	private String server;
	private String servernum;
	private int inmount;
	private float price;
	private String cgy;
	public String getFno() {
		return fno;
	}
	public void setFno(String fno) {
		this.fno = fno;
	}
	public Date getIntime() {
		return intime;
	}
	public void setIntime(Date intime) {
		this.intime = intime;
	}
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getServernum() {
		return servernum;
	}
	public void setServernum(String servernum) {
		this.servernum = servernum;
	}
	public int getInmount() {
		return inmount;
	}
	public void setInmount(int inmount) {
		this.inmount = inmount;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getCgy() {
		return cgy;
	}
	public void setCgy(String cgy) {
		this.cgy = cgy;
	}
	
	
	
	
	
	
	
}
