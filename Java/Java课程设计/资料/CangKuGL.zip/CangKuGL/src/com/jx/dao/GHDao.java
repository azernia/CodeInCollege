package com.jx.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.jx.dto.GHInfo;
import com.jx.util.DBcon;
import com.jx.util.DateType;

public class GHDao {
	public ResultSet query(String sql) {
		Statement pst = null;
		Connection conn = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			pst = conn.createStatement(1005,1008);
			rs = pst.executeQuery(sql);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}
		
		return rs;
	}
	public boolean addGHInfo(GHInfo gh) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = DBcon.getConnection();
			String sql = "insert into ghinfo(fno,dept,ghmount,ghtime,jsr,instate) values(?,?,?,?,?,?);";
			pst = conn.prepareStatement(sql);
			pst.setString(1, gh.getFno());
			pst.setString(2, gh.getDept());
			pst.setInt(3, gh.getGhmount());
			pst.setDate(4, gh.getGhtime());
			pst.setString(5, gh.getJsr());
			pst.setString(6, gh.getInstate());
			if (pst.executeUpdate() > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return flag;
	}

}
