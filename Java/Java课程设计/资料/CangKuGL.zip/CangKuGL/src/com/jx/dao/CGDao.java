package com.jx.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import com.jx.dto.CGInfo;
import com.jx.dto.GHInfo;
import com.jx.dto.Manager;
import com.jx.util.DBcon;
import com.jx.util.DateType;


public class CGDao {
	public boolean addSB(CGInfo cg) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = DBcon.getConnection();
			String sql = "insert into cginfo(fno,cgy,server,buymount,buytime,servernum,price) values(?,?,?,?,?,?,?);";
			pst = conn.prepareStatement(sql);
			pst.setString(1, cg.getFno());
			pst.setString(2, cg.getCgy());
			pst.setString(3, cg.getServer());
			pst.setInt(4, cg.getBuymount());
			pst.setDate(5, DateType.convertFormUtilDate(cg.getBuytime()));
			pst.setString(6, cg.getServernum());
			pst.setFloat(7, cg.getPrice());
			if (pst.executeUpdate() > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return flag;
	}
public ResultSet query(String sql) {
		
		Statement pst = null;
		Connection conn = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			pst = conn.createStatement(1005,1008);
			rs = pst.executeQuery(sql);
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}
		return rs;
	}
public CGInfo queryFno(String fno) {
		
		PreparedStatement pst = null;
		Connection conn = null;
		ResultSet rs = null;
		String sql="select * from cginfo where fno=?";
		CGInfo cg=null;

		try {
			conn = DBcon.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, fno);
			rs = pst.executeQuery();
			if(rs.next())
			{
				cg=new CGInfo();
				cg.setFno(rs.getString(1));
				cg.setCgy(rs.getString(2));
				cg.setServer(rs.getString(3));
				cg.setBuymount(rs.getInt(4));
				cg.setBuytime(rs.getDate(5));
				cg.setServernum(rs.getString(6));
				cg.setPrice(rs.getFloat(7));
			}
			
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}
		return cg;
	}
public boolean updateFno(CGInfo cg) {
	boolean flag=false;
	PreparedStatement pst = null;
	Connection conn = null;
	ResultSet rs = null;
	String sql="update cginfo set buymount=buymount+? where fno=?";


	try {
		conn = DBcon.getConnection();
		pst = conn.prepareStatement(sql);
		pst.setInt(1, cg.getBuymount());
		pst.setString(2, cg.getFno());
		rs = pst.executeQuery();
		if(rs.next())
		{
			cg=new CGInfo();
			cg.setFno(rs.getString(1));
			cg.setCgy(rs.getString(2));
			cg.setServer(rs.getString(3));
			cg.setBuymount(rs.getInt(4));
			cg.setBuytime(rs.getDate(5));
			cg.setServernum(rs.getString(6));
			cg.setPrice(rs.getFloat(7));
		}
		
		flag=true;

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} finally {
		
	}
	return flag;
}

	

}
