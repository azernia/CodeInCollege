package com.jx.dto;

import java.sql.Date;

public class GHInfo {
	private String fno;
	private String dept;
	private int ghmount;
	private Date ghtime;
	private String jsr;
	private String instate;
	public String getFno() {
		return fno;
	}
	public void setFno(String fno) {
		this.fno = fno;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getGhmount() {
		return ghmount;
	}
	public void setGhmount(int ghmount) {
		this.ghmount = ghmount;
	}
	public Date getGhtime() {
		return ghtime;
	}
	public void setGhtime(Date ghtime) {
		this.ghtime = ghtime;
	}
	public String getJsr() {
		return jsr;
	}
	public void setJsr(String jsr) {
		this.jsr = jsr;
	}
	public String getInstate() {
		return instate;
	}
	public void setInstate(String instate) {
		this.instate = instate;
	}
	

}
