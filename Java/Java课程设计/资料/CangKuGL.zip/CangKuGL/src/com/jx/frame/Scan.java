package com.jx.frame;
import javax.swing.JTextArea;

public class Scan extends Thread {
	int array[];
	JTextArea jTextArea_text;
	int now;
	int d;

	public Scan(int d, int array[], int now, JTextArea jTextArea_text) {
		this.now = now;
		this.array = array;
		this.jTextArea_text = jTextArea_text;
		this.d = d;
	}

	public void run() {
		final int MAX = 100;
		int temp, k = 0, l, r, q = 0, sum = 0, i, j;
		float avg = 0;
		int print[] = new int[array.length + 1];

		for (i = 0; i < array.length; i++)
			for (j = i; j < array.length; j++) {
				if (array[i] > array[j]) {
					temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}

		if (array[array.length - 1] <= now) // ��ǰ���ŵ���
		{
			if (d == 0) {
				sum += MAX - now;
				now = MAX;
				print[q] = MAX;
				q++;
				for (i = array.length - 1; i >= 0; i--) {
					print[q] = array[i];
					q++;
					sum += now - array[i];
					now = array[i];
				}
			}
			if (d == 1) {
				for (i = array.length - 1; i >= 0; i--) {
					print[q] = array[i];
					sum += now - array[i];
					now = array[i];
					q++;
				}

			}

		} else {
			if (array[0] >= now) // ��ǰ��С�ŵ���
			{
				if (d == 0) {
					for (i = 0; i < array.length; i++) {
						print[q] = array[i];
						sum += array[i] - now;
						now = array[i];
						q++;
					}
				}
				if (d == 1) {
					sum+=now-0;
					now=0;
					print[q]=0;
					q++;
					for (i = 0; i < array.length; i++) {
						print[q] = array[i];
						sum += array[i] - now;
						now = array[i];
						q++;
					}
					

				}
			} else // ��ǰ�Ĵŵ��ŵ�ֵ�������б����ʵ��µĴŵ���֮��
			{
				while (array[k] < now) // ȷ����ǰ�ŵ������ŵ������е�λ��
				{
					k++;
				}
				l = k - 1;
				r = k;

				switch (d) {
				case 1: // ����ŵ��ż�С�������
				{
					while (l >= 0) {
						print[q] = array[l];
						q++;
						sum = sum + now - array[l];
						now = array[l];
						l = l - 1;
					}
					sum += now - 0;
					now = 0;
					print[q] = 0;
					q++;
					for (j = r; j < array.length; j++) {
						print[q] = array[j];
						q++;
						sum += array[j] - now;
						now = array[j];
					}
					break;
				}
				case 0: // ����ŵ������ӷ������
				{
					while (r < array.length) {
						print[q] = array[r];
						q++;
						sum = sum + array[r] - now;
						now = array[r];
						r = r + 1;
					}
					sum += MAX - now;
					now = MAX;
					print[q] = MAX;
					q++;
					for (j = l; j >= 0; j--) {
						print[q] = array[j];
						q++;
						sum = sum + now - array[j];
						now = array[j];
					}
					break;
				}
				default:
					return;
				}
			}
		}
		avg = sum / (array.length);

		jTextArea_text.setText("");
		if (d == 0) {
			jTextArea_text.append("ɨ���㷨��ŵ������ӵķ���ִ�ж��У�");
		}
		if (d == 1) {
			jTextArea_text.append("ɨ���㷨��ŵ��ż�С�ķ���ִ�ж��У�");
		}

		for (int n = 0; n < print.length; n++) {
			try {
				this.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			jTextArea_text.append(print[n] + "  ");
		}
		jTextArea_text.append("\nƽ��Ѱ�����ȣ�" + sum + "\nƽ���ƶ�����:" + avg);
	}
}
