package com.jx.frame;
import javax.swing.JTextArea;
//���Ѱ��ʱ�������㷨
public class SSTF extends Thread{
	int array[];
	JTextArea jTextArea_text;
	int now;
	public SSTF(int array[],int now,JTextArea jTextArea_text){
		this.now=now;
		this.array=array;
		this.jTextArea_text=jTextArea_text;
	}
	public void run(){
		double avg = 0;
		int temp, k,l, r, i, j, sum = 0, q = 0;
		int print[] = new int[array.length];

		// ���ŵ��Ŵ�С��������
		for (i = 0; i < array.length; i++)
			for (j = i; j < array.length; j++) {
				if (array[i] > array[j]) {
					temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}

		// ��ǰ���Ĵŵ���
		if (array[array.length - 1] <= now) {
			for (i = array.length - 1; i >= 0; i--) {
				print[q] = array[i];
				q++;
				sum += now - array[i];
				now = array[i];
			}
		} else {// ��ǰ��С�Ĵŵ���
			if (array[0] >= now) {
				for (i = 0; i < array.length; i++) {
					print[q] = array[i];
					q++;
					sum += array[i] - now;
					now = array[i];
				}
			} else // ��ǰ�Ĵŵ��ŵ�ֵ�������б����ʵ��µĴŵ���֮��
			{
				for ( k = 0; k < array.length; k++) {
					if (array[k] > now) {
						break;
					}
				}
				l = k - 1;
				r = k;
				while (l >= 0 && r < array.length) {
					if ((now - array[l]) <= (array[r] - now)) {
						sum += now - array[l];
						now = array[l];
						print[q] = array[l];
						q++;
						l--;
					} else {
						sum += array[r] - now;
						now = array[r];
						print[q] = array[r];
						q++;
						r++;
					}
				}
				
				while (l >= 0) {
					print[q] = array[l];
					q++;
					sum += now - array[l];
					now = array[l];
					l--;
				}

				while (r < array.length) {
					sum += array[r] - now;
					now = array[r];
					print[q] = array[r];
					q++;
					r++;
				}
			}
		}
		avg = sum / (array.length+0.0);
		
		jTextArea_text.setText("");
		jTextArea_text.append("���Ѱ��ʱ�������㷨ִ�ж���: ");

		for (int n = 0; n < print.length; n++) {
			try{
				this.sleep(500);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
			jTextArea_text.append(print[n]+"  ");
		}
		jTextArea_text.append( "\nƽ��Ѱ�����ȣ�" + sum
				+ "\nƽ���ƶ�����:" + avg);
	}
	
}
