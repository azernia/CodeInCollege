package com.jx.frame;

import java.awt.Color;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.jx.dto.CGInfo;
import com.jx.dao.CGDao;



public class CGJFrameView extends JInternalFrame implements ActionListener{
//	private JComboBox combox_manager;
	private JTextField text_cno, text_date;
	private JButton button_search, button_clear,button_update;
	int row=0;
	private JTable table; // �������
	private DefaultTableModel tableModel;

	GridBagLayout gridBag = new GridBagLayout();
	GridBagConstraints gridBagCon;

	public CGJFrameView() throws SQLException {
		super("�豸�ɹ���Ϣ");
		this.setSize(800, 400);
		this.setLocation(10, 10);
		this.setBackground(Color.lightGray);
		this.setResizable(false);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		JSplitPane js = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		JPanel up = new JPanel(new GridLayout(2, 1));
		js.add(up);
		this.getContentPane().add(js);

//		up.add(new Label("���ò�ѯ������         "));

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		up.add(panel);

//		panel.add(new Label("�豸��   "));
//		text_cno = new JTextField("", 12);
//		panel.add(text_cno);
		

		
//
//		button_search = new JButton("��ѯ");
//		panel.add(button_search);
//		this.setVisible(true);
//		button_search.addActionListener(this);
//		button_clear = new JButton("����");
//		panel.add(button_clear);
//		this.setVisible(true);
//		button_clear.addActionListener(this);
		

		CGDao dao = new CGDao();
		String sql = "select fno,cgy,server,buymount,buytime,servernum,price from cginfo";
		ResultSet rs = dao.query(sql);
		String sbcgb[] = {"�豸��","�ɹ�Ա","��Ӧ��","����","����","��Ӧ�̵绰","�۸�"};
		tableModel = new DefaultTableModel(sbcgb,0);
		table = new JTable(tableModel);
		JScrollPane jspane = new JScrollPane(table);
		jspane.setViewportView(table);	
		while(rs.next())
		{
			row++;
		}
		System.out.println("row="+row);
		ResultSetMetaData data=rs.getMetaData();
		int column=data.getColumnCount();
		String data_xy[][]=new String[row][column];
		rs.beforeFirst();
		for(int i=0;i<row;i++)
		{
			rs.next();
			for(int j=1;j<=column;j++)
				data_xy[i][j-1]=rs.getString(j);
			tableModel.addRow(data_xy[i]);
		}
		js.add(jspane);

		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
//		if (e.getActionCommand().equals("��ѯ")) {	
//			System.out.println("1111");
//			SBCGDao dao=new SBCGDao();
//			SBCG sb=dao.queryEno(text_cno.getText());
//			for(int i=0;i<row;i++)
//			{
//				tableModel.removeRow(i);
//			}
//			Object sbcg[]={sb.getEno(),sb.getCgy(),sb.getSupplier(),sb.getCgmount(),sb.getCgdate(),sb.getSupplycall(),sb.getPrice()};
//			tableModel.addRow(sbcg);
//			System.out.println("sssss");
//			}


		if (e.getSource() == button_clear) {
			text_cno.setText("");

		}
		
		if (e.getActionCommand().equals("ˢ��")) {
			
		}
	}


}
