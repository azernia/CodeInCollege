package com.jx.frame;
import javax.swing.JTextArea;

public class FCFS extends Thread {
	int array[];
	JTextArea jTextArea_text;
	int now;

	public FCFS(int array[], int now, JTextArea jTextArea_text) {
		this.now = now;
		this.array = array;
		this.jTextArea_text = jTextArea_text;
	}

	public void run() {
		int j, i, sum;
		float avg = 0;
		sum = Math.abs(now - array[0]);
		for (i = 0, j = 1; j < array.length; i++, j++)
			sum = sum + Math.abs((array[j] - array[i]));// ���ƶ���
		avg = sum / (array.length);

		jTextArea_text.setText("");
		jTextArea_text.append("�����ȷ���ִ�ж��У�");
		for (int n = 0; n < array.length; n++) {
			try {
				this.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jTextArea_text.append(array[n] + "  ");
		}
		jTextArea_text.append("\nƽ��Ѱ�����ȣ�" + sum + "\nƽ���ƶ�����:" + avg);
	}

}
