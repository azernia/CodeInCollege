package com.jx.frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

//import CangKuGL.jx.frame;
//import cangku.BaoSunSelectView;
//import cangku.CangKuFrame;
//import cangku.GongJieZhangDialogView;
//import cangku.GongShopView;
//import cangku.GongYingshangDailogView;
//import cangku.JiageTiaozhengDialogView;
//import cangku.KucunselectDialog;
//import cangku.OperatorView;
//import cangku.ShopChuKuDialogView;
//import cangku.ShopChuKuSelectView;
//import cangku.ShopRuKuDialogView;
//import cangku.ShopTuiHuoDialogView;
//import cangku.ShopTuiHuoSelectView;
//import cangku.shopRuKuSelectView;

public class CangkuHandler implements ActionListener{
	MyJFrame Frame;
    public CangkuHandler(MyJFrame Frame){
        this.Frame=Frame;
    }
    public void CGGL() throws SQLException{                 //�ɹ���Ϣ����
        CGJFrameGL CGGl=new CGJFrameGL();
        CGGl.setBounds(200,200,600,280);
        CGGl.setVisible(true);
        CGGl.setResizable(false);
    }
    public void CKGL() throws SQLException{             //�豸������Ϣ����
        CKJFrameGL CKGl=new CKJFrameGL();
        CKGl.setBounds(200,200,600,280);
        CKGl.setVisible(true);
        CKGl.setResizable(false);
    }
    public void GHGL() throws SQLException{          //�豸�黹��Ϣ����
        GHJFrameGL GHGl=new GHJFrameGL();
        GHGl.setBounds(200,200,450,300);
        GHGl.setVisible(true);
        GHGl.setResizable(false);
    }
   
    public void XQGL() throws SQLException{         //�豸������Ϣ����
        XQJFrameGL XQGl=new XQJFrameGL();
        XQGl.setBounds(200,200,550,300);
        XQGl.setVisible(true);
        XQGl.setResizable(false);
    }
    public void CGJFrameView() throws SQLException{             //�黹��Ϣ��ѯ
    	CGJFrameView CGView=new CGJFrameView();
    	CGView.setBounds(200,200,750,450);
//    	CGView.str=Frame.lblOption1.getText().trim();
    	CGView.setVisible(true);
    	CGView.setResizable(false);
      }
    public void CKJFrameView() throws SQLException{           //������Ϣ��ѯ
    	CKJFrameView GHView=new CKJFrameView();
    	GHView.setBounds(200,200,750,450);
//    	GHView.str=Frame.lblOption1.getText().trim();
    	GHView.setVisible(true);
    	GHView.setResizable(false);
       }
//    public void ShopChuKu(){                //��Ʒ�������
//        ShopChuKuDialogView ChuKu=new ShopChuKuDialogView();
//        ChuKu.mm=Frame.lblOption1.getText().trim();
//        ChuKu.setBounds(200,200,650,380);
//        ChuKu.setVisible(true);
//        ChuKu.setResizable(false);
//    }
//    public void JiageTiaozheng(){            //���۸����
//        JiageTiaozhengDialogView Jiage=new JiageTiaozhengDialogView();
//        Jiage.setBounds(200,200,450,280);
//        Jiage.setVisible(true);
//        Jiage.setResizable(false);
//    }
//    public void BaoYuan(){             //��Ʒ�������
//        BaoSunGuanliDialogView Bao=new BaoSunGuanliDialogView();
//        Bao.setBounds(200,200,600,350);
//        Bao.setVisible(true);
//        Bao.setResizable(false);
//    }
//   
//    public void shopkucunselect(){        //����ѯ
//      KucunselectDialog shopruku=new KucunselectDialog();
//      shopruku.setBounds(200,200,740,410);
//      shopruku.setVisible(true);
//      shopruku.setResizable(true);
//
//    }
//    public void shopRuKuSelect(){    //��Ʒ����ѯ
//        shopRuKuSelectView RuKuSelect=new shopRuKuSelectView();
//        RuKuSelect.setBounds(200,200,700,320);
//        RuKuSelect.setVisible(true);
//        RuKuSelect.setResizable(false);
//    }
//    public void shopChuKuSelect(){   //��Ʒ�����ѯ
//        ShopTuiHuoSelectView shopChuKu=new ShopTuiHuoSelectView();
//        shopChuKu.setBounds(200,200,700,320);
//        shopChuKu.setVisible(true);
//        shopChuKu.setResizable(false);
//    }
//    public void TiHouSelect(){    //����˻���ѯ
//        ShopChuKuSelectView tihou=new ShopChuKuSelectView();
//        tihou.setBounds(200,200,700,320);
//        tihou.setVisible(true);
//        tihou.setResizable(false);
//    }
//    public void BaoYuanSelect(){              //��Ʒ�����ѯ
//        BaoSunSelectView BaoYuan=new BaoSunSelectView();
//        BaoYuan.setBounds(200,200,700,320);
//        BaoYuan.setVisible(true);
//        BaoYuan.setResizable(false);
//    }
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

  
   
//    public void actionPerformed(ActionEvent e) {
//        if(e.getActionCommand()=="Jinfogong"){                       //��Ӧ����Ϣ����
//            Gong();
//        }
//        if(e.getActionCommand()=="Jinfoshop"){                       //��Ʒ��Ϣ����
//            GongShop();
//        }
//        if(e.getActionCommand()=="Joperator"){                       //����Ա����
//            GongOperator();
//        }
//
//        if(e.getActionCommand()=="exit"){
//           System.exit(0);
//        }
//
//      
//
//        if(e.getActionCommand()=="Caccount"){                        //��Ӧ�̽��˹���
//            GongWangLaiJieZhang();
//        }
//        if(e.getActionCommand()=="Fmerchandise"){                    //��Ʒ������
//               ShopRuKuDialog();
//            }
//        if(e.getActionCommand()=="Fmerchandisewh"){                  //��Ʒ����˴�����
//               ShopTuiHouDialog();
//           }
//        if(e.getActionCommand()=="Wwarehouse"){                     //��Ʒ�������
//            ShopChuKu();
//        }
//        if(e.getActionCommand()=="Wprice"){                         //���۸����
//            JiageTiaozheng();
//        }
//        if(e.getActionCommand()=="Wkiosk"){                         //��Ʒ�������
//            BaoYuan();
//        }
//    
//
//
//        if(e.getActionCommand()=="Qincome"){                       //��Ʒ����ѯ
//            shopRuKuSelect();
//        }
//        if(e.getActionCommand()=="Qcancel"){                       //����˴���ѯ
//            shopChuKuSelect();
//        }
//        if(e.getActionCommand()=="Qlookup"){                       //����ѯ
//             shopkucunselect();
//        }
//
//        if(e.getActionCommand()=="Qchuku"){                        //��Ʒ�����ѯ
//            TiHouSelect();
//        }
//        if(e.getActionCommand()=="Qbaoyuan"){                     //��Ʒ�����ѯ
//            BaoYuanSelect();
//        }
//
//
//       if(e.getActionCommand()=="sbtn1"){                      //��Ӧ����Ϣ����
//            Gong();
//        }
//        if(e.getActionCommand()=="sbtn2"){                      //��Ʒ������
//            ShopRuKuDialog();
//        }
//
//        if(e.getActionCommand()=="sbtn4"){                     //��Ʒ�۸����
//            JiageTiaozheng();
//        }
//        if(e.getActionCommand()=="sbtn5"){                     //��Ʒ�������
//            BaoYuan();
//        }
//        if(e.getActionCommand()=="sbtn6"){                     //����Ѱ
//             shopRuKuSelect();
//        }
//        if(e.getActionCommand()=="sbtn7"){                    //�����Ѱ
//             TiHouSelect();
//        }
//        if(e.getActionCommand()=="sbtn8"){                     //�����ѯ
//            BaoYuanSelect();
//        }
//
//      
//      }
}
