package com.jx.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.jx.dto.CKInfo;
import com.jx.dto.GHInfo;
import com.jx.util.DBcon;

public class CKDao {
	public ResultSet query(String sql) {
		Statement pst = null;
		Connection conn = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			pst = conn.createStatement(1005,1008);
			rs = pst.executeQuery(sql);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}		
		return rs;
	}
	public boolean addCKInfo(CKInfo ck) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = DBcon.getConnection();
			String sql = "insert into sbck(eno,dept,outdate,state,jsr,outmount,lqr,useto) values(?,?,?,?,?,?,?,?);";
			pst = conn.prepareStatement(sql);
			pst.setString(1, ck.getFno());
			pst.setString(2, ck.getDept());
			pst.setDate(3, ck.getOuttime());
			pst.setString(4, ck.getOutstate());
			pst.setString(5, ck.getJsr());
			pst.setInt(6, ck.getOutmount());
			pst.setString(7, ck.getLqr());
			pst.setString(8, ck.getUsefor());
			
			if (pst.executeUpdate() > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return flag;
	}

}
