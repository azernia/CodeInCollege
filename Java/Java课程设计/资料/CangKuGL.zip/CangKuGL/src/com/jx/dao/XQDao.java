package com.jx.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.jx.dto.XQInfo;
import com.jx.util.DBcon;

public class XQDao {
	public ResultSet query(String sql) {
		Statement pst = null;
		Connection conn = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			pst = conn.createStatement(1005,1008);
			rs = pst.executeQuery(sql);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}
		
		return rs;
	}
	public boolean addXQInfo(XQInfo xq) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = DBcon.getConnection();
			String sql = "insert into xqinfo(dept,fno,xqmount,xqtime) values(?,?,?,?);";
			pst = conn.prepareStatement(sql);
			pst.setString(1, xq.getDept());
			pst.setString(2, xq.getFno());
			pst.setInt(3, xq.getXqmount());
			pst.setString(4, xq.getXqtime());

			
			if (pst.executeUpdate() > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return flag;
	}
	public boolean deleteXQInfo(String dept)
	{
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = DBcon.getConnection();
			String sql = "delete from xqinfo where dept=?;";
			pst = conn.prepareStatement(sql);
			pst.setString(1, dept);
			

			
			if (pst.executeUpdate() > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBcon.closeConn(pst);
			DBcon.closeConn(conn);
		}
		return flag;
	}

}
