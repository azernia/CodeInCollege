package com.jx.frame;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class PageSwitch extends JFrame implements ActionListener {
	public JRadioButton up = new JRadioButton("����");
	public JRadioButton down = new JRadioButton("����");
	private JTextField text_no, text_queue, text_now;
	private JButton[] jbutton;
	private JButton jButton_random;
	private JTextArea jTextArea_text;
	private int[] array;
	private int n, now;

	public PageSwitch() {
		super("	�ƶ��۵����㷨");
		this.setSize(600, 300);
		this.setLocation(200, 80);
		this.setBackground(Color.lightGray);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		// ���ӷָ���
		this.getContentPane().setLayout(new GridLayout());
		JSplitPane south = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		south.setDividerLocation(100);
		this.getContentPane().add(south);

		JPanel panel = new JPanel(new GridLayout(3, 1));
		south.add(panel);

		jTextArea_text = new JTextArea("");
		south.add(new JScrollPane(jTextArea_text));
		//jTextArea_text.setEnabled(false);

		JPanel panel_1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel.add(panel_1);
		panel_1.add(new Label("���г��ȣ�"));
		text_no = new JTextField(7);
		panel_1.add(text_no);
		panel_1.add(new Label("�����뵱ǰ�ŵ��ţ�"));
		text_now = new JTextField(7);
		panel_1.add(text_now);

		JPanel panel_2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel.add(panel_2);
		jButton_random = new JButton("�������");
		panel_2.add(jButton_random);
		jButton_random.addActionListener(this);
		text_queue = new JTextField(39);
		text_queue.setEditable(false);
		panel_2.add(text_queue);
		//text_queue.setEnabled(false);

		JPanel panel_3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel.add(panel_3);
		String[] menuarray = { "�����ȷ����㷨", "��̲���ʱ�������㷨", "���ݵ����㷨" ,"ɨ���㷨"};
		jbutton = new JButton[menuarray.length];
		for (int i = 0; i < menuarray.length; i++) {
			jbutton[i] = new JButton(menuarray[i]);
			panel_3.add(jbutton[i]);
			this.setVisible(true);
			jbutton[i].addActionListener(this);
		}
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("�������")) {
			try {
				n = Integer.parseInt(text_no.getText());
				now = Integer.parseInt(text_now.getText());
			} catch (NumberFormatException nfe) {
				JOptionPane.showMessageDialog(this, "������������");
				return;
			}
			if (n > 20 || n <= 0) {
				JOptionPane.showMessageDialog(this, "���г�������д��ΧΪ1~20��������");
				return;
			}

			new InDuilie(n);

		}

		if (e.getActionCommand().equals("�����ȷ����㷨")) {
			if(text_queue.getText().equals("")){
				JOptionPane.showMessageDialog(this, "����δ������");
				return ;				
			}				
			new FCFS(array, now, jTextArea_text).start();
		}

		if (e.getActionCommand().equals("��̲���ʱ�������㷨")) {
			if(text_queue.getText().equals("")){
				JOptionPane.showMessageDialog(this, "����δ������");
				return ;				
			}
			new SSTF(array, now, jTextArea_text).start();
		}

		if (e.getActionCommand().equals("���ݵ����㷨")) {
			if(text_queue.getText().equals("")){
				JOptionPane.showMessageDialog(this, "����δ������");
				return ;				
			}
			new Confirm();
		}
		
		if (e.getActionCommand().equals("ɨ���㷨")) {
			if (text_queue.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "����δ������");
				return;
			}
			new Confirm1();
		}
	}
	class InDuilie extends JFrame implements ActionListener
	{
		private JPanel panel;
		private JButton button1,button2;
		private JTextField [] textFields;
		public InDuilie(int n) {
			// TODO Auto-generated constructor stub
			super("�������");
			this.setBounds(300, 150, 300, 300);
			panel=new JPanel(new GridLayout(n+1,2));
			textFields=new JTextField[n];
			for(int i=1;i<=n;i++)
			{
				textFields[i-1]=new JTextField(8);
				panel.add(new JLabel(i+"���У�",0));
				panel.add(textFields[i-1]);
			}
			button1=new JButton("ȷ��");
			button1.addActionListener(this);
			panel.add(button1);
			button2=new JButton("ȡ��");
			button2.addActionListener(this);
			panel.add(button2);
			this.getContentPane().add(panel);
			this.setVisible(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==button1)
			{
				String str="";
				array=new int[n];
				for(int i=1;i<=n;i++)
				{
					array[i-1]=Integer.parseInt(textFields[i-1].getText());
					str=str+array[i-1]+" ";
				}
				text_queue.setText(str);
				this.setVisible(false);
			}
			if(e.getSource()==button2)
			{
				this.setVisible(false);
			}
		}
	}

	// �ڲ���
	class Confirm extends JFrame implements ActionListener {
		JButton button;
		Confirm() {
			super("ѡ����ݵ��ȷ���");
			this.setBounds(300, 150, 300, 100);
			this.setLayout(new FlowLayout());
			ButtonGroup jbg = new ButtonGroup();
			jbg.add(up);
			up.setSelected(true);
			jbg.add(down);
			button = new JButton("ȷ��");
			button.addActionListener(this);
			
			this.getContentPane().add(up);
			this.getContentPane().add(down);		
			this.getContentPane().add(button);
			this.setVisible(true);
		}

		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==button)
			{
				int dw = 0 ;
				if (up.isSelected()) {
					dw = 0;
				} 
				if (down.isSelected()) {
					dw = 1;
				}
				new Elevator(dw,array,now, jTextArea_text).start();
			}
		}
	}
	
	// �ڲ���1
	class Confirm1 extends JFrame implements ActionListener {
		JButton button ;
		Confirm1() {
			super("ѡ����ȷ���");
			this.setBounds(300, 150, 300, 100);
			this.setLayout(new FlowLayout());
			ButtonGroup jbg = new ButtonGroup();
			jbg.add(up);
			up.setSelected(true);
			jbg.add(down);
			button = new JButton("ȷ��");
			button.addActionListener(this);

			this.getContentPane().add(up);
			this.getContentPane().add(down);
			this.getContentPane().add(button);
			this.setVisible(true);
		}

		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==button)
			{
				int dw = 0 ;
				if (up.isSelected()) {
					dw = 0;
				} 
				if (down.isSelected()) {
					dw = 1;
				}
				new Scan(dw,array,now, jTextArea_text).start();
				
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new PageSwitch();
	}
}