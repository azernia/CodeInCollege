package com.jx.dao;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.jx.util.DBcon;

public class RKDao {
public ResultSet query(String sql) {
		
		Statement pst = null;
		Connection conn = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			pst = conn.createStatement(1005,1008);
			rs = pst.executeQuery(sql);
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}
		return rs;
	}

}
