package com.jx.frame;


import java.awt.FlowLayout;



import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;


import javax.swing.JButton;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.jx.dto.CGInfo;
import com.jx.dto.CKInfo;
import com.jx.dto.GHInfo;
import com.jx.dto.XQInfo;
import com.jx.dao.CGDao;
import com.jx.dao.CKDao;
import com.jx.dao.GHDao;
import com.jx.dao.XQDao;
import com.jx.util.DateType;





public class XQJFrameView extends JInternalFrame implements ActionListener{
//	private JComboBox combox_manager;
	private JTextField text_cno, text_date;
	private JButton button_search, button_clear,button_update,button1,button2,button3,button4;
	private JSplitPane splitPane_v;//�ָ���
	JTextField textField1,textField2,textField3,textField4;
	private JTable table; // �������
	private DefaultTableModel tableModel;

	public XQJFrameView() throws SQLException {
		super("�豸����鿴");
		this.setSize(800, 400);
		this.setLocation(10, 10);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
//		JPanel left=new JPanel();
//		JPanel panel1=new JPanel(new GridLayout(11,2));
//		
//		
//
//		JPanel panel2=new JPanel();
//		
//
//		JLabel label=new JLabel("���ţ�",0);
//		JLabel labe2=new JLabel("�����豸�ţ�",0);
//		JLabel labe3=new JLabel("��Ҫ������",0);
//		JLabel labe4=new JLabel("�������ڣ�",0);
//
//		
//		textField1=new JTextField();
//		textField2=new JTextField();
//		textField3=new JTextField();
//		textField4=new JTextField();
//
//
//		button1=new JButton("ȷ��");
//		button2=new JButton("����");
//		button3=new JButton("ȡ��");
//		button4 =new JButton("ɾ��");
//		button1.addActionListener(this);
//		button2.addActionListener(this);
//		button3.addActionListener(this);
//		button4.addActionListener(this);
//		panel1.add(label);
//		panel1.add(textField1);
//		panel1.add(labe2);
//		panel1.add(textField2);
//		panel1.add(labe3);
//		panel1.add(textField3);
//		panel1.add(labe4);
//		panel1.add(textField4);
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel2.add(button1);
//		panel2.add(button2);
//		panel2.add(button3);
//		panel2.add(button4);
//		left.add(panel1);
//		left.add(panel2);
//	
//		splitPane_v= new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);// ˮƽ�ָ�
//		splitPane_v.setDividerLocation(250);
//		splitPane_v.add(left);
		
		
		

		JSplitPane js = new JSplitPane(JSplitPane.VERTICAL_SPLIT);   //��ֱ�ָ�
		JPanel up = new JPanel(new GridLayout(2, 1));
		
		
		this.getContentPane().add(js);



		XQDao dao = new XQDao();
		String sql = "select dept,fno,xqmount,xqtime from xqinfo";
		ResultSet rs = dao.query(sql);
		String sbcgb[] = {"����","�����豸��","��������","��������"};
		tableModel = new DefaultTableModel(sbcgb,0);
		table = new JTable(tableModel);
		JScrollPane jspane = new JScrollPane(table);
		int row=0;
		while(rs.next())
		{
			row++;
		}
		System.out.println("row="+row);
		ResultSetMetaData data=rs.getMetaData();
		int column=data.getColumnCount();
		String data_xy[][]=new String[row][column];
		rs.beforeFirst();
		for(int i=0;i<row;i++)
		{
			rs.next();
			for(int j=1;j<=column;j++)
				data_xy[i][j-1]=rs.getString(j);
			tableModel.addRow(data_xy[i]);
		}
		js.add(up);
		js.add(jspane);
		this.add(js);
		
//		splitPane_v.add(js);
//		this.add(splitPane_v);


		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("ȡ��")) {				
				this.setVisible(false);
			}


		if (e.getActionCommand().equals("ȷ��")) {
			XQInfo xq=new XQInfo();
			xq.setDept(textField1.getText());
			xq.setFno(textField2.getText());
			xq.setXqmount(Integer.parseInt(textField3.getText()));
			xq.setXqtime(textField4.getText());
			
			XQDao dao=new XQDao();
			dao.addXQInfo(xq);
		}
		
		if (e.getActionCommand().equals("����")) {
			textField1.setText("");
			textField2.setText("");
			textField3.setText("");
			textField4.setText("");
			

			
		}
		if (e.getActionCommand().equals("ɾ��")) {
			
			String dept=textField1.getText();
			XQDao dao =new XQDao();
			dao.deleteXQInfo(dept);
			
			

			
		}
	}
//	public static void main(String[] args) {
//		new SBCGJFramegl();
//	}


}
