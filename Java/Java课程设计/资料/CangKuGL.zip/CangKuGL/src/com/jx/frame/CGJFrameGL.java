package com.jx.frame;


import java.awt.FlowLayout;



import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;


import javax.swing.JButton;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.jx.dto.CGInfo;
import com.jx.dao.CGDao;
import com.jx.util.DateType;





public class CGJFrameGL extends JInternalFrame implements ActionListener{
//	private JComboBox combox_manager;
	private JTextField text_cno, text_date;
	private JButton button_search, button_clear,button_update,button1,button2,button3;
	private JSplitPane splitPane_v;//�ָ���
	JTextField textField1,textField2,textField3,textField4,textField5,textField6,textField7;
	private JTable table; // �������
	private DefaultTableModel tableModel;

	public CGJFrameGL() throws SQLException {
		super("�豸�ɹ�����");
		this.setSize(900, 500);
		this.setLocation(10, 10);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		JPanel left=new JPanel();
		JPanel panel1=new JPanel(new GridLayout(12,2));
		
		

		JPanel panel2=new JPanel();
		

		JLabel label=new JLabel("�豸�ţ�",0);
		JLabel labe2=new JLabel("�ɹ�Ա��",0);
		JLabel labe3=new JLabel("�ṩ�̣�",0);
		JLabel labe4=new JLabel("�ɹ�������",0);
		JLabel labe5=new JLabel("�ɹ����ڣ�",0);
		JLabel labe6=new JLabel("�ṩ�̵绰��",0);
		JLabel labe7=new JLabel("���ۣ�",0);
		textField1=new JTextField();
		textField2=new JTextField();
		textField3=new JTextField();
		textField4=new JTextField();
		textField5=new JTextField("�����Զ�����");
		textField6=new JTextField();
		textField7=new JTextField();

		button1=new JButton("ȷ��");
		button2=new JButton("����");
		button3=new JButton("ȡ��");
		button1.addActionListener(this);
		button2.addActionListener(this);
		button3.addActionListener(this);
		panel1.add(label);
		panel1.add(textField1);
		panel1.add(labe2);
		panel1.add(textField2);
		panel1.add(labe3);
		panel1.add(textField3);
		panel1.add(labe4);
		panel1.add(textField4);
		panel1.add(labe5);
		panel1.add(textField5);
		panel1.add(labe6);
		panel1.add(textField6);
		panel1.add(labe7);
		panel1.add(textField7);
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel1.add(new JPanel());
		panel2.add(button1);
		panel2.add(button2);
		panel2.add(button3);
		left.add(panel1);
		left.add(panel2);
	
		splitPane_v= new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);// ˮƽ�ָ�
		splitPane_v.setDividerLocation(200);
		splitPane_v.add(left);
		
		
		

		JSplitPane js = new JSplitPane(JSplitPane.VERTICAL_SPLIT);   //��ֱ�ָ�
		JPanel up = new JPanel(new GridLayout(2, 1));
		
		
		this.getContentPane().add(js);

//		up.add(new Label("���ò�ѯ������ģ�����ң���         "));

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		up.add(panel);

//		panel.add(new Label("�豸��   "));
//		text_cno = new JTextField("", 12);
//		panel.add(text_cno);
//		button_search = new JButton("��ѯ");
//		panel.add(button_search);
//		this.setVisible(true);
//		button_search.addActionListener(this);

		CGDao dao = new CGDao();
		String sql = "select fno,cgy,server,buymount,buytime,servernum,price from cginfo";
		ResultSet rs = dao.query(sql);
		String cg[] = {"�豸��","�ɹ�Ա","��Ӧ��","����","����","��Ӧ�̵绰","�۸�"};
		tableModel = new DefaultTableModel(cg,0);
		table = new JTable(tableModel);
		JScrollPane jspane = new JScrollPane(table);
		int row=0;
		while(rs.next())
		{
			row++;
		}
		System.out.println("row="+row);
		ResultSetMetaData data=rs.getMetaData();
		int column=data.getColumnCount();
		String data_xy[][]=new String[row][column];
		rs.beforeFirst();
		for(int i=0;i<row;i++)
		{
			rs.next();
			for(int j=1;j<=column;j++)
				data_xy[i][j-1]=rs.getString(j);
			tableModel.addRow(data_xy[i]);
		}
		js.add(up);
		js.add(jspane);
		
		splitPane_v.add(js);
		this.add(splitPane_v);


		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("ȡ��")) {				
				this.setVisible(false);
			}


		if (e.getActionCommand().equals("ȷ��")) {
			CGInfo cg=new CGInfo();
			cg.setFno(textField1.getText());
			cg.setCgy(textField2.getText());
			cg.setServer(textField3.getText());
			cg.setBuymount(Integer.parseInt(textField4.getText()));
			GregorianCalendar   now   =   new   GregorianCalendar();  
			cg.setBuytime((Date) DateType.convertFormUtilDate(now.getTime()));
			cg.setServernum(textField6.getText());
			cg.setPrice(Float.parseFloat(textField7.getText()));
			CGDao dao=new CGDao();
			dao.addSB(cg);
			JOptionPane.showMessageDialog(this, "�ɹ��ɹ�"+cg.getFno()+"�豸"+cg.getBuymount()+"��");
			
				
			
		}
		
		if (e.getActionCommand().equals("����")) {
			textField1.setText("");
			textField2.setText("");
			textField3.setText("");
			textField4.setText("");
			textField5.setText("�����Զ�����");
			textField6.setText("");
			textField7.setText("");
			
		}
	}
//	public static void main(String[] args) {
//		new SBCGJFramegl();
//	}


}
