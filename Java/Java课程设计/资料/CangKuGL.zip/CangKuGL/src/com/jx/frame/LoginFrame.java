package com.jx.frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import com.jx.dto.Manager;
import com.jx.dao.ManagerDao;



public class LoginFrame extends JFrame implements ActionListener{
	
	JLabel mLogin = new JLabel(new ImageIcon("image/li.jpg"));
    JLabel mName = new JLabel();
    JLabel mpwd = new JLabel();
    JTextField text_manager = new JTextField();
    JButton button_ok = new JButton(new ImageIcon("image/yes.jpg"));
    JButton button_cancel = new JButton(new ImageIcon("image/exit.jpg"));
    JPasswordField text_password = new JPasswordField();
    TitledBorder titledBorder1 = new TitledBorder("");
    TitledBorder titledBorder2 = new TitledBorder("");
    TitledBorder titledBorder3 = new TitledBorder("");
    TitledBorder titledBorder4 = new TitledBorder("");
    JLabel lblbiao = new JLabel();
    TitledBorder titledBorder5 = new TitledBorder("");
    JButton btnanniao = new JButton(new ImageIcon("image/key.jpg"));
//	private JLabel managername, password;
//	private JTextField text_manager; // �û����ı���
//	private JPasswordField text_password; // �����ı���
//
//	private JButton button_ok, button_cancel;
//	public boolean isLogin = false; // �жϵ�¼�Ƿ�ɹ�

	public LoginFrame() {
		super("ϵͳ��¼"); 
		this.setSize(350, 200);
		this.setLocation(550, 200);
		this.setBackground(Color.lightGray);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new FlowLayout());
		
		mLogin.setBackground(SystemColor.inactiveCaptionText);
		mLogin.setPreferredSize(new Dimension(123, 95));
        this.getContentPane().setLayout(null);
        mLogin.setText("");
        mLogin.setBounds(new Rectangle(10, 20, 75, 70));
        this.getContentPane().setBackground(UIManager.getColor("Label.background"));
        this.setForeground(Color.lightGray);
//        lblName.setBackground(Color.black);
//        lblName.setFont(new java.awt.Font("����", Font.BOLD, 13));
//        lblName.setForeground(Color.blue);
//        lblName.setFont(new java.awt.Font("����", Font.PLAIN, 13));
//        lblName.setBorder(BorderFactory.createLoweredBevelBorder());
//        lblName.setText("");
//        lblName.setBounds(new Rectangle(191, 26, 110, 25));
//        text_manager.addActionListener(this);
        mName.setFont(new java.awt.Font("����", Font.BOLD, 13));
        mName.setForeground(Color.blue);
        mName.setText("����Ա�˺ţ�");
        mName.setBounds(new Rectangle(93, 30, 86, 20));
        
        mpwd.setFont(new java.awt.Font("����", Font.BOLD, 13));
        mpwd.setForeground(Color.blue);
        mpwd.setText("����Ա���룺");
        mpwd.setBounds(new Rectangle(93, 63, 86, 24));
        
        button_ok.setBounds(new Rectangle(73, 109, 79, 22));
        button_ok.setFont(new java.awt.Font("����", Font.PLAIN, 13));
        button_ok.setBorder(BorderFactory.createRaisedBevelBorder());
        button_ok.setPreferredSize(new Dimension(79, 22));
        button_ok.setText("");
        this.getContentPane().add(button_ok);
      //  button_ok.setActionCommand("enter");
        button_ok.addActionListener(this);
        
        button_cancel.setBounds(new Rectangle(179, 109, 79, 23));
        button_cancel.setFont(new java.awt.Font("����", Font.PLAIN, 13));
        button_cancel.setBorder(BorderFactory.createRaisedBevelBorder());
        button_cancel.setPreferredSize(new Dimension(79, 23));
        button_cancel.setText("");
        this.getContentPane().add(button_cancel);
     //   button_cancel.setActionCommand("Exit");
        button_cancel.addActionListener(this);
        
        text_manager.setBorder(BorderFactory.createLoweredBevelBorder());
        text_manager.setText("");
        text_manager.setBounds(new Rectangle(191, 30, 110, 25));
        
        text_password.setBorder(BorderFactory.createLoweredBevelBorder());
        text_password.setText("");
        text_password.setBounds(new Rectangle(191, 63, 110, 25));

        lblbiao.setForeground(Color.red);
        lblbiao.setText("");
        lblbiao.setBounds(new Rectangle(192, 89, 108, 19));
        
//        btnanniao.setBounds(new Rectangle(173, 72, 18, 10));
//        btnanniao.setPreferredSize(new Dimension(18, 10));
//        btnanniao.addActionListener(this);
        
        this.getContentPane().add(text_manager);
        this.getContentPane().add(text_password);
        this.getContentPane().add(mLogin);
        this.getContentPane().add(button_cancel);
        this.getContentPane().add(button_ok);
        this.getContentPane().add(lblbiao);
        this.getContentPane().add(mpwd);
        this.getContentPane().add(mName);
        this.getContentPane().add(btnanniao);
		this.setVisible(true);
//		super("�û���¼");
//		this.setSize(240, 120);
//		this.setLocation(550, 200);
//		this.setBackground(Color.lightGray);
//		this.setResizable(false);
//		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
//		this.getContentPane().setLayout(new FlowLayout());
//		
//
//		managername = new JLabel("�û�����");
//		managername.setFont(new Font("Dialog", 0, 12));
//		this.getContentPane().add(managername);
//		text_manager = new JTextField("admin",15);
//		this.getContentPane().add(text_manager);
//		password = new JLabel("��    �룺");
//		password.setFont(new Font("Dialog", 0, 12));
//		this.getContentPane().add(password);
//		text_password = new JPasswordField("1111",15);
//		this.getContentPane().add(text_password);
//
//		button_ok = new JButton("��¼");
//		button_ok.setFont(new Font("Dialog", 0, 12));
//		this.getContentPane().add(button_ok);
//		button_ok.addActionListener(this);
//		button_cancel = new JButton("ȡ��");
//		button_cancel.setFont(new Font("Dialog", 0, 12));
//		this.getContentPane().add(button_cancel);
//		button_cancel.addActionListener(this);
//		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) // �����¼���������
	{
		Manager manager = new Manager();
		String managername = text_manager.getText();
		if (managername.equals(""))
		            lblbiao.setText("�������û�����");
//			JOptionPane.showMessageDialog(this, "�������û���");
		else 
			if (new String(text_password.getPassword()).equals(""))
		            lblbiao.setText("�������û����룡");
//				JOptionPane.showMessageDialog(this, "������mima");
		String password =new String(text_password.getPassword());
		
		manager.setManagername(managername);
		manager.setPassword(password);
		
		if (e.getSource() == button_cancel) // �����˳���ť
		{
			this.setVisible(false);
		} 
		else if (e.getSource() == button_ok)// ������¼��ť
		{
			System.out.println(managername);
			System.out.println(password);
			ManagerDao managerDao = new ManagerDao();
			Manager m = managerDao.validate(manager);
			if(m == null)
			{
				lblbiao.setText("�û��������벻��ȷ��");
//				JOptionPane.showMessageDialog(this, "�û��������������");
				return;
			}
			new MyJFrame(manager);
		}
	}

	public static void main(String args[]) throws Exception // ���Է���
	{
		new LoginFrame();
	}


}
