package com.jx.frame;


import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.sql.SQLException;


import javax.swing.*;


//import cangku.LoginModel;
//import cangku.MenuHandler;

import com.jx.dto.Manager;
import com.jx.frame.CGJFrameView;
import com.jx.frame.CGJFrameGL;
import com.jx.frame.CKJFrameView;
import com.jx.frame.CKJFrameView;
import com.jx.frame.GHJFrameView;
import com.jx.frame.GHJFrameGL;
import com.jx.frame.RKJFrameView;
import com.jx.frame.XQJFrameView;
import com.jx.frame.XQJFrameGL;
import com.jx.frame.KCJFrameView;


public class MyJFrame extends JFrame implements ActionListener{
	
	private JMenuBar menubar;
	private JDesktopPane desktop;
	private JMenu[] menu;
	private Manager manager;
	JLabel welcome = new JLabel();
	private JMenuItem[] menuitems, menuitems2, menuitems3;
	private String[] itemstr = { "�û�����", "���ص�¼","�˳�"};
	private String[] itemstr2 = { "�豸�ɹ�����", "�豸�黹����", "�豸�������", "�豸�������" };
	private String[] itemstr3 = { "��ǰ�ֿ���Ϣ", "�豸�����Ϣ", "�豸������Ϣ", "�豸�黹��Ϣ",
			"�豸�ɹ���Ϣ", "�豸������Ϣ" };

	MyJFrame(Manager manager) {
		super("�ֿ����ϵͳ");
		this.manager=manager;
		this.setBounds(120, 50, 500, 400);
		desktop = new JDesktopPane();
		menubar = new JMenuBar();	
		this.getContentPane().add(desktop);
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		}

		String[] menustr = { "ϵͳ����", "�豸����", "��ѯ����" };
		menu = new JMenu[menustr.length];
		for (int i = 0; i < menustr.length; i++) {
			menu[i] = new JMenu(menustr[i]);
			menubar.add(menu[i]);
		}

		menuitems = new JMenuItem[itemstr.length];
		for (int i = 0; i < itemstr.length; i++) {
			menuitems[i] = new JMenuItem(itemstr[i]);
			menuitems[i].addActionListener(this);
			menu[0].add(menuitems[i]);
		}

		menuitems2 = new JMenuItem[itemstr2.length];
		for (int i = 0; i < itemstr2.length; i++) {
			menuitems2[i] = new JMenuItem(itemstr2[i]);
			menuitems2[i].addActionListener(this);
			menu[1].add(menuitems2[i]);
		}
		
		menuitems3 = new JMenuItem[itemstr3.length];
		for (int i = 0; i < itemstr3.length; i++) {
			menuitems3[i] = new JMenuItem(itemstr3[i]);
			menuitems3[i].addActionListener(this);
			menu[2].add(menuitems3[i]);
		}
		
		welcome.setFont(new java.awt.Font("����", Font.BOLD, 40));
		welcome.setForeground(Color.blue);
		welcome.setText("��ӭ��½�ֿ����ϵͳ��");
		welcome.setBounds(new Rectangle(93, 30, 86, 20));
		this.getContentPane().add(welcome);
		
		this.setJMenuBar(menubar);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("�û�����")) {
			JOptionPane.showMessageDialog(this, "��û�и�Ȩ�ޣ�");
		}
		if (e.getActionCommand().equals("���ص�¼")) {
			this.setVisible(false);
			new LoginFrame();
		}
		if (e.getActionCommand().equals("�˳�")) {
			JOptionPane.showMessageDialog(this, "��лʹ�òֿ���Ϣ����ϵͳ��");
			System.exit(0);
		}
		if (e.getActionCommand().equals("�豸�ɹ�����")) {
			CGJFrameGL framegl;
			try {
				framegl = new CGJFrameGL();
				desktop.removeAll();
				desktop.add(framegl);
				framegl.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
		if (e.getActionCommand().equals("�豸�黹����")) {
			try {
				GHJFrameGL framegl = new GHJFrameGL();
				desktop.removeAll();
				desktop.add(framegl);
				framegl.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
		if (e.getActionCommand().equals("�豸�������")) {
			try {
				CKJFrameGL framegl = new CKJFrameGL();
				desktop.removeAll();
				desktop.add(framegl);
				framegl.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand().equals("�豸�������")) {
			try {
				XQJFrameGL framegl =new XQJFrameGL();
				desktop.removeAll();
				desktop.add(framegl);
				framegl.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand().equals("��ǰ�ֿ���Ϣ")) {
			try {
				KCJFrameView frame = new KCJFrameView();
				desktop.removeAll();
				desktop.add(frame);
				frame.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		if (e.getActionCommand().equals("�豸�����Ϣ")) {
			try {
				RKJFrameView frameck =new RKJFrameView();
				desktop.removeAll();
				desktop.add(frameck);
				frameck.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand().equals("�豸������Ϣ")) {
			try {
				CKJFrameView frameck = new CKJFrameView();
				desktop.removeAll();
				desktop.add(frameck);
				frameck.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand().equals("�豸�黹��Ϣ")) {
			try {
				GHJFrameView frameck = new GHJFrameView();
				desktop.removeAll();
				desktop.add(frameck);
				frameck.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand().equals("�豸�ɹ���Ϣ")) {
			try {
				CGJFrameView frameCX=new CGJFrameView();
				desktop.removeAll();
				desktop.add(frameCX);
				frameCX.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand().equals("�豸������Ϣ")) {
			try {
				XQJFrameView frameck =new XQJFrameView();
				desktop.removeAll();
				desktop.add(frameck);
				frameck.setVisible(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
}