package com.jx.dto;

import java.sql.Date;

public class XQInfo {
	private String dept;
	private String fno;
	private int xqmount;
	private String xqtime;
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getFno() {
		return fno;
	}
	public void setFno(String fno) {
		this.fno = fno;
	}
	public int getXqmount() {
		return xqmount;
	}
	public void setXqmount(int xqmount) {
		this.xqmount = xqmount;
	}
	public String getXqtime() {
		return xqtime;
	}
	public void setXqtime(String xqtime) {
		this.xqtime = xqtime;
	}
	
	
	
	
	

}
