package com.jx.dto;

import java.sql.Date;

public class CGInfo {
	private String fno;
	private String cgy;
	private String server;
	private int buymount;
	private Date buytime;
	private String servernum;
	private float price;
	public String getFno() {
		return fno;
	}
	public void setFno(String fno) {
		this.fno = fno;
	}
	public String getCgy() {
		return cgy;
	}
	public void setCgy(String cgy) {
		this.cgy = cgy;
	}
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}

	public int getBuymount() {
		return buymount;
	}
	public void setBuymount(int buymount) {
		this.buymount = buymount;
	}
	public Date getBuytime() {
		return buytime;
	}
	public void setBuytime(Date buytime) {
		this.buytime = buytime;
	}
	public String getServernum() {
		return servernum;
	}
	public void setServernum(String servernum) {
		this.servernum = servernum;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
	
	
	
	

}
