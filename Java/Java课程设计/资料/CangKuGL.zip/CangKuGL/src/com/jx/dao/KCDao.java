package com.jx.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import com.jx.dto.CGInfo;
import com.jx.dto.CKInfo;
import com.jx.dto.KCInfo;
import com.jx.util.DBcon;

public class KCDao {
	public ResultSet query(String sql) {
		Statement pst = null;
		Connection conn = null;
		ResultSet rs = null;

		try {
			conn = DBcon.getConnection();
			pst = conn.createStatement(1005,1008);
			rs = pst.executeQuery(sql);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}
		
		return rs;
	}
public KCInfo queryFno(String fno) {
		
		PreparedStatement pst = null;
		Connection conn = null;
		ResultSet rs = null;
		String sql="select fno,mount,total,max,min from kcinfo where fno=?";
		KCInfo kc=null;

		try {
			conn = DBcon.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, fno);
			rs = pst.executeQuery();
			if(rs.next())
			{
				 kc=new KCInfo();
				kc.setFno(rs.getString(1));
				kc.setMount(rs.getInt(2));
				kc.setTotal(rs.getInt(3));
				kc.setMax(rs.getInt(4));
				kc.setMin(rs.getInt(5));
			}
			
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
		}
		return kc;
	}
public boolean updateKCInfo(CKInfo ck) {
	boolean flag=false;
	PreparedStatement pst = null;
	Connection conn = null;
	String sql="update kcinfo set mount=mount-? where fno=?";


	try {
		conn = DBcon.getConnection();
		pst = conn.prepareStatement(sql);
		pst.setInt(1, ck.getOutmount());
		pst.setString(2, ck.getFno());
		if( pst.executeUpdate()>0)
			flag=true;

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} finally {
		
	}
	return flag;
}

}
