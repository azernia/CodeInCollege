package com.jx.frame;


import java.awt.FlowLayout;



import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;


import javax.swing.JButton;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.jx.dto.CGInfo;
import com.jx.dto.CKInfo;
import com.jx.dto.GHInfo;
import com.jx.dao.CGDao;
import com.jx.dao.CKDao;
import com.jx.dao.GHDao;
import com.jx.util.DateType;





public class CKJFrameView extends JInternalFrame implements ActionListener{
//	private JComboBox combox_manager;
	private JTextField text_cno, text_date;
	private JButton button_search, button_clear,button_update,button1,button2,button3;
	private JSplitPane splitPane_v;//�ָ���
	JTextField textField1,textField2,textField3,textField4,textField5,textField6,textField7,textField8;
	private JTable table; // �������
	private DefaultTableModel tableModel;

	public CKJFrameView() throws SQLException {
		super("�豸����鿴");
		this.setSize(800, 400);
		this.setLocation(10, 10);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
//		JPanel left=new JPanel();
//		JPanel panel1=new JPanel(new GridLayout(11,2));
//		
//		
//
//		JPanel panel2=new JPanel();
//		
//
//		JLabel label=new JLabel("�豸�ţ�",0);
//		JLabel labe2=new JLabel("���ò��ţ�",0);
//		JLabel labe3=new JLabel("�������ڣ�",0);
//		JLabel labe4=new JLabel("���ʱ״̬��",0);
//		JLabel labe5=new JLabel("�����ˣ�",0);
//		JLabel labe6=new JLabel("���������",0);
//		JLabel labe7=new JLabel("��ȡ�ˣ�",0);
//		JLabel labe8=new JLabel("��;��",0);
//		
//		textField1=new JTextField();
//		textField2=new JTextField();
//		textField3=new JTextField("�����Զ�����");
//		textField4=new JTextField();
//		textField5=new JTextField();
//		textField6=new JTextField();
//		textField7=new JTextField();
//		textField8=new JTextField();
//
//		button1=new JButton("ȷ��");
//		button2=new JButton("����");
//		button3=new JButton("ȡ��");
//		button1.addActionListener(this);
//		button2.addActionListener(this);
//		button3.addActionListener(this);
//		panel1.add(label);
//		panel1.add(textField1);
//		panel1.add(labe2);
//		panel1.add(textField2);
//		panel1.add(labe3);
//		panel1.add(textField3);
//		panel1.add(labe4);
//		panel1.add(textField4);
//		panel1.add(labe5);
//		panel1.add(textField5);
//		panel1.add(labe6);
//		panel1.add(textField6);
//		panel1.add(labe7);
//		panel1.add(textField7);
//		panel1.add(labe8);
//		panel1.add(textField8);
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel1.add(new JPanel());
//		panel2.add(button1);
//		panel2.add(button2);
//		panel2.add(button3);
//		left.add(panel1);
//		left.add(panel2);
//	
//		splitPane_v= new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);// ˮƽ�ָ�
//		splitPane_v.setDividerLocation(200);
//		splitPane_v.add(left);
		
		
		

		JSplitPane js = new JSplitPane(JSplitPane.VERTICAL_SPLIT);   //��ֱ�ָ�
		JPanel up = new JPanel(new GridLayout(2, 1));
		
		
		this.getContentPane().add(js);



		CKDao dao = new CKDao();
		String sql = "select fno,dept,outtime,outstate,jsr,outmount,lqr,usefor from ckinfo";
		ResultSet rs = dao.query(sql);
		String sbcgb[] = {"�豸��","���ò���","��������","���ʱ״̬","������","�������","��ȡ��","��;"};
		tableModel = new DefaultTableModel(sbcgb,0);
		table = new JTable(tableModel);
		JScrollPane jspane = new JScrollPane(table);
		int row=0;
		while(rs.next())
		{
			row++;
		}
		System.out.println("row="+row);
		ResultSetMetaData data=rs.getMetaData();
		int column=data.getColumnCount();
		String data_xy[][]=new String[row][column];
		rs.beforeFirst();
		for(int i=0;i<row;i++)
		{
			rs.next();
			for(int j=1;j<=column;j++)
				data_xy[i][j-1]=rs.getString(j);
			tableModel.addRow(data_xy[i]);
		}
		js.add(up);
		js.add(jspane);
		this.add(js);
		
//		splitPane_v.add(js);
//		this.add(splitPane_v);


		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("ȡ��")) {				
				this.setVisible(false);
			}


		if (e.getActionCommand().equals("ȷ��")) {
			CKInfo ck=new CKInfo();
			ck.setFno(textField1.getText());
			ck.setDept(textField2.getText());
			ck.setOutstate(textField4.getText());
			GregorianCalendar   now   =   new   GregorianCalendar();  
			ck.setOuttime((Date) DateType.convertFormUtilDate(now.getTime()));
			ck.setJsr(textField5.getText());
			ck.setOutmount(Integer.parseInt(textField6.getText()));
			ck.setLqr(textField7.getText());
			ck.setUsefor(textField8.getText());
			CKDao dao=new CKDao();
			dao.addCKInfo(ck);
		}
		
		if (e.getActionCommand().equals("����")) {
			textField1.setText("");
			textField2.setText("");
			textField3.setText("");
			textField4.setText("�����Զ�����");
			textField5.setText("");
			textField6.setText("");

			
		}
	}
//	public static void main(String[] args) {
//		new SBCGJFramegl();
//	}


}
