package com.jx.frame;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import javax.swing.table.DefaultTableModel;

import com.jx.dao.KCDao;




public class KCJFrameView extends JInternalFrame {
//	private JComboBox combox_manager;

	private JTable table; // �������
	private DefaultTableModel tableModel;


	public KCJFrameView() throws SQLException {
		super("���п����Ϣ��ѯ");
		this.setSize(800, 400);
		this.setLocation(10, 10);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);



		KCDao dao = new KCDao();
		String sql = "select * from kcinfo";
		ResultSet rs = dao.query(sql);
		String kc[] = {"�豸��","��������","������","�������","��С�����","״̬"};
		tableModel = new DefaultTableModel(kc,0);
		table = new JTable(tableModel);
		JScrollPane jspane = new JScrollPane(table);
		int row=0;
		while(rs.next())
		{
			row++;
		}
		ResultSetMetaData data=rs.getMetaData();
		int column=data.getColumnCount();
		String data_xy[][]=new String[row][column];
		rs.beforeFirst();
		for(int i=0;i<row;i++)
		{
			rs.next();
			for(int j=1;j<=column;j++)
				data_xy[i][j-1]=rs.getString(j);
			tableModel.addRow(data_xy[i]);
		}
		this.add(jspane);

		this.setVisible(true);
	}

//	public static void main(String[] args) {
//		new XYKCJFrameCk();
//	}



}
